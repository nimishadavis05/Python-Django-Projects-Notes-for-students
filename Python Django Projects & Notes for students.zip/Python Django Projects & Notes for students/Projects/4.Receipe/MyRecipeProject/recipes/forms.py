from django.forms import ModelForm
from recipes.models import Recipe
from django import forms
class CreateRecipeForm(ModelForm):
    created_by=forms.CharField(widget=forms.TextInput(attrs={'readonly':'readonly'}))
    ingrediants=forms.CharField(widget=forms.Textarea)
    class Meta:
        model=Recipe
        fields=["recipe_name","ingrediants","category","recipe_img","created_by"]