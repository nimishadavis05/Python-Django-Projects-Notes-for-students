from django.shortcuts import render,redirect
from .filters import RecipeFilter
# Create your views here.

from recipes.forms import CreateRecipeForm
from recipes.models import Recipe

def CreateRecipe(request):
    form=CreateRecipeForm(initial={"created_by":request.user})
    context={}
    context["form"]=form
    if request.method=="POST":
        form=CreateRecipeForm(data=request.POST,files=request.FILES)
        if form.is_valid():
            form.save()
            return redirect("listrecipe")
        else:
            context["form"]=form
            return render(request,"recipes/createterecipe.html",context)
    return render(request,"recipes/createterecipe.html",context)


def listrecipe(request):
    my_recipe=Recipe.objects.filter(created_by=request.user)
    context={}
    context["recipes"]=my_recipe
    return render(request,"recipes/listrecipe.html",context)


def view_recipe(request,id):
    recipe = Recipe.objects.get(id=id)
    context={}
    context["recipe"]=recipe
    return render(request,"recipes/recipeview.html",context)


def edit_recipe(request,id):
    recipe=Recipe.objects.get(id=id)
    form=CreateRecipeForm(instance=recipe)
    context={}
    context["form"]=form
    if request.method=="POST":
        form=CreateRecipeForm(instance=recipe,data=request.POST,files=request.FILES)
        if form.is_valid():
            form.save()
            return redirect("listrecipe")
        else:
            context["form"]=form
            return render(request, "recipes/editrecipe.html", context)

    return render(request,"recipes/editrecipe.html",context)


def delete_recipe(request,id):
    Recipe.objects.get(id=id).delete()
    return redirect("listrecipe")


def search_recipe(request):
    recipes=Recipe.objects.all()
    myfilter=RecipeFilter(request.GET,queryset=recipes)
    recipes=myfilter.qs
    context={}
    context["recipes"]=recipes
    context["myfilter"]=myfilter
    return render(request,"recipes/recipesearch.html",context)