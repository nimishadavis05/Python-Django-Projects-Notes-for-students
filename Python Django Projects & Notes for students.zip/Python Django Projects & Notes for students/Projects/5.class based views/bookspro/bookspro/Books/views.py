# from django.shortcuts import render

# # Create your views here.

# from django.views.generic import CreateView,ListView,UpdateView,DetailView,DeleteView
# from Books.models import Book
# from django.urls import reverse_lazy
# def IndexView(request):
#     return render(request,"Books/index.html")
# class BookCreate(CreateView):
#     model=Book
#     fields="__all__"
#     template_name="Books/book_form.html"
#     success_url=reverse_lazy('list')

# class BookList(ListView):
#     model=Book  
#     template_name="Books/book_list.html"  
#     context_object_name="books"

# class BookEdit(UpdateView):
#     model=Book
#     fields="__all__"
#     template_name="Books/book_edit.html"  
#     success_url=reverse_lazy('list')
    
# class BookView(DetailView):
#     model=Book
#     context_object_name="book"
#     template_name="Books/book_detail.html"  

# class BookDelete(DeleteView):
#     model=Book
#     context_object_name="book"
#     template_name="Books/book_delete.html"  
#     success_url=reverse_lazy('list')



from django.views.generic import CreateView,ListView,UpdateView,DetailView,DeleteView,TemplateView
from Books.forms import BookCreateForm
from django.shortcuts import render,redirect
from .models import Book

def IndexView(request):
    return render(request,"Books/index.html")

class BookCreate(TemplateView):
    form_class=BookCreateForm()
    template_name="Books/book_form.html"
    context={}
    def get(self,request,*args,**kwargs):
        form=BookCreateForm()
        self.context["form"]=form
        return render(request,self.template_name,self.context)
    def post(self,request,*args,**kwargs):
        form=BookCreateForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("list")

class BookList(TemplateView):
    model=Book
    template_name="Books/book_list.html"            
    context={}
    def get_query_set(self):
        return self.model.objects.all()

    def get(self,request,*args,**kwargs):
        self.context["books"]=self.get_query_set()
        return render(request,self.template_name,self.context)
    
class BookEdit(TemplateView):
    model=Book
    template_name="Books/book_edit.html"
    context={}
    def get_query_set(self,id):
        return self.model.objects.get(id=id)

    def get(self,request,*args,**kwargs):
        book=self.get_query_set(kwargs.get("pk"))
        form=BookCreateForm(instance=book)
        self.context["form"]=form
        return render(request,self.template_name,self.context)

    def post(self,request,*args,**kwargs):
        book=self.get_query_set(kwargs.get("pk"))
        form=BookCreateForm(instance=book,data=request.POST)
        if form.is_valid():
            form.save()
            return redirect("list")

class BookDelete(TemplateView):
    model=Book
    template_name="Books/book_delete.html"
    context={}
    def get_query_set(self,id):
        return self.model.objects.get(id=id)

    def get(self,request,*args,**kwargs):
        book=self.get_query_set(kwargs.get("pk"))
        book.delete()
        return redirect("list")