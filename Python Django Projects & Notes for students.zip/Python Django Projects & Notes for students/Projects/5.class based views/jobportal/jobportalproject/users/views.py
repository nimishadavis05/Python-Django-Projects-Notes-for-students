from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy
from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
# Create your views here.
from django.views.generic import TemplateView,CreateView,UpdateView
from .forms import UserRegistrationForm,LoginForm,AddCompanyForm
from .models import Company
from django.contrib.auth.models import User
class Index(TemplateView):
    template_name="users/index.html"

class userhome(TemplateView):
    template_name="users/userhome.html"

class Register(TemplateView):

	form_class=UserRegistrationForm()
	template_name="users/register.html"
	context={}
	def get(self,request,*args,**kwargs):
		form=UserRegistrationForm()
		self.context["form"]=form
		return render(request,self.template_name,self.context)
	def post(self,request,*args,**kwargs):
		form=UserRegistrationForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect("Index")
		else:
			self.context["form"]=form
			return render(request,self.template_name,self.context)

class Login(TemplateView):
	form_class=LoginForm()
	template_name="users/login.html"
	context={}
	def get(self,request,*args,**kwargs):
		form=LoginForm()
		self.context["form"]=form
		return render(request,self.template_name,self.context)
 
	def post(self,request,*args,**kwargs):
		form=LoginForm(request.POST)
		if form.is_valid():
			username=form.cleaned_data.get("username")
			password=form.cleaned_data.get("password")
			user=authenticate(request,username=username,password=password)
			if user:
				login(request,user)
				return redirect("userhome")
			else:
				return redirect("login")


class addcompany(TemplateView):
    form_class=AddCompanyForm()
    template_name="users/company.html"
    context={}
    def get(self,request,*args,**kwargs):
    	form=AddCompanyForm()
    	self.context["form"]=form
    	return render(request,self.template_name,self.context)

    def post(self,request,*args,**kwargs):
    	form=AddCompanyForm(request.POST)
    	if form.is_valid():
    		form.save()
    		
    		return redirect("CompanyList")
    	else:
    		print("error")
    		self.context["form"]=form
    		return render(request,self.template_name,self.context)


class SignOut(TemplateView):
	template_name="users/index.html"
	context={}
	def get(self,request,*args,**kwargs):
		logout(request)
		return render(request,self.template_name,self.context)


class CompanyList(TemplateView):
	model=Company
	template_name="users/viewmycompanies.html"
	context={}
	def get_query_set(self,user):
		return self.model.objects.get(created_by=user)
	def get(self,request,*args,**kwargs):
		created_by=request.user
		self.context["companys"]=self.get_query_set(created_by)
		return render(request,self.template_name,self.context)

# class CompanyEdit(UpdateView):
#     model=Company
#     fields="__all__"
#     template_name="users/editcompany.html"  
#     success_url=reverse_lazy('CompanyList')

class CompanyEdit(TemplateView):
	model=Company
	template_name="users/editcompany.html"
	context={}
	def get_query_set(self,id):		
		return self.model.objects.get(id=id)
	def get(self,request,*args,**kwargs):
		company=self.get_query_set(kwargs.get("pk"))
		form=AddCompanyForm(instance=company)
		self.context["form"]=form
		return render(request,self.template_name,self.context)
	def post(self,request,*args,**kwargs):
		company=self.get_query_set(kwargs.get("pk"))
		form=AddCompanyForm(instance=company,data=request.POST)
		if form.is_valid():
			form.save()
			return redirect("CompanyList")

