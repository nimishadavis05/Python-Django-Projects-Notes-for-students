"""jobportalproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path
from users.views import Index,Register,userhome,Login,addcompany,SignOut,CompanyList,CompanyEdit

urlpatterns = [
    path("Index",Index.as_view(),name="Index"),
    path("Register",Register.as_view(),name="Register"),
    path("userhome",userhome.as_view(),name="userhome"),
    path("Login",Login.as_view(),name="Login"),
    path("addcompany",addcompany.as_view(),name="addcompany"),
    path("SignOut",SignOut.as_view(),name="SignOut"),
    path("CompanyList",CompanyList.as_view(),name="CompanyList"),
    path("CompanyEdit/<int:pk>",CompanyEdit.as_view(),name="CompanyEdit"),
    
]
