from django.db import models
from django.contrib.auth.models import User
# Create your models here.

# Create your models here.
class Company(models.Model):
	companyname=models.CharField(max_length=230)
	location=models.CharField(max_length=230)
	website=models.CharField(max_length=230)
	contact_no=models.IntegerField()
	created_by=models.CharField(max_length=120)
	def __str__(self):
		return self.companyname