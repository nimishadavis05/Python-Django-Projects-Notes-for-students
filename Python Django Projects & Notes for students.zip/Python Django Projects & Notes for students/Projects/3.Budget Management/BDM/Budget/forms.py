from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import User
from django import forms
from  Budget.models import Expenses
class RegistrationForm(UserCreationForm):
    class Meta:
        model=User
        fields=["first_name","last_name","email","username","password1","password2"]

class LoginForm(forms.Form):
    username=forms.CharField(max_length=120)
    password=forms.CharField(max_length=120)
    def clean(self):
        print("inside clean")


class AddExpenseForm(ModelForm):
    user=forms.CharField(widget=forms.TextInput(attrs={'readonly':'readonly'})) #to make user editable false
    class Meta:
        model=Expenses #model form anel ethanu model enn paraynam
        fields=["category","amount","note","user"]
        #to fetch all forms
        #fields=”__all__”
class ReviewExpense(forms.Form):
    user=forms.HiddenInput()
    from_date=forms.DateField(widget=forms.SelectDateWidget())
    to_date=forms.DateField(widget=forms.SelectDateWidget())
    



    

    