from django.db import models

# Create your models here.

class Category(models.Model):
    category_name=models.CharField(max_length=120,unique=True)
    #override str__ :say what to return
    def __str__(self):
        return self.category_name
    
class Expenses(models.Model):
    # set foreignkey  : on delete use cheyunath,category delete ayal mukalile modelilnum ponam
    category =models.ForeignKey(Category,on_delete=models.CASCADE)
    amount=models.IntegerField()
    date=models.DateField(auto_now=True) # current date varan as default
    note=models.CharField(max_length=120) #optional
    user=models.CharField(max_length=120) #which user adding this
    
    def __str__(self):
        return str(str(self.amount)+self.user)
