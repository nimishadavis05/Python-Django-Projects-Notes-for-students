"""BDM URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from Budget.views import Index,register,signin,signout,editProfile,userHome,addExpense,editExpenses,deleteExpenses,review_expense,tempinherit

urlpatterns = [
    path("",Index,name="Index"),
    path("register",register,name="register"),
    path("login",signin,name="login"),
    path("signout",signout,name="signout"),
    path("editProfile",editProfile,name="editProfile"),
    path("userHome",userHome,name="userHome"),
    path("addExpense",addExpense,name="addExpense"),
    path("editexpense/<int:pk>",editExpenses,name="editexpense"),
    path("deleteExpenses/<int:pk>",deleteExpenses,name="deleteExpenses"),
    path("review_expense",review_expense,name="review_expense"),
    path("tempinherit",tempinherit,name="tempinherit")

]