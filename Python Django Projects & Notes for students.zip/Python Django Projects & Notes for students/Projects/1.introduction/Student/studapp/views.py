from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def studLogin(request):
    # return HttpResponse("hello welcome")
    return render(request,"studapp/home.html")

def register(request):
    return render(request,"studapp/register.html")

def demo(request):
    return render(request,"studapp/demo.html")


def regDetails(request):
    semail=request.POST.get("studemail")
    spwd=request.POST.get("studpwd")
    print("email:",semail)
    print("pwd:",spwd)
    context={}
    context["studemail"]=semail
    context["studpwd"]=spwd
    return render(request,"studapp/login.html",context)

def addition(request):
    number1=int(request.POST.get("num1"))
    number2=int(request.POST.get("num2"))
    number3=number1+number2
    print("number1:",number1)
    print("number2:",number2)
    context={}
    context["number1"]=number1
    context["number2"]=number2
    context["number3"]=number3
    return render(request,"studapp/demo1.html",context)