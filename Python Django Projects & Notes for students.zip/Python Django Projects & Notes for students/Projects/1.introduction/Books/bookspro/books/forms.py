from django import forms
class BookCreateForm(forms.Form):
    bname=forms.CharField(max_length=150)
    price=forms.IntegerField()
    pages=forms.IntegerField()
    author=forms.CharField(max_length=120)
     