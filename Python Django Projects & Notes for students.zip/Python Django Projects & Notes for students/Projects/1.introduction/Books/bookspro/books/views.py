from django.shortcuts import render,redirect
from books.models import Book
from books.forms import BookCreateForm
# Create your views here.

def createBook(request):
    return render(request,"books/index.html")

def insertbook(request):
    bname=request.POST.get("bname")
    price=request.POST.get("price")
    pages=request.POST.get("pages")
    author=request.POST.get("author")
    context={}
    context["bname"]=bname
    context["price"]=price
    context["pages"]=pages
    context["author"]=author
    print(bname,price,pages,author)
    book=Book(bname=bname,pages=pages,price=price,author=author)
    book.save()
    # return render(request,"books/view.html",context)
    return redirect("getbook")

def getBook(request):
    books=Book.objects.all()
    context={}
    context["books"]=books
    return render(request,"books/listbook.html",context)
def AddBook(request):
    form=BookCreateForm()
    context={}
    context["form"]=form
    if(request.method=='POST'):
        form=BookCreateForm(request.POST)
        if(form.is_valid()):
            bname=form.cleaned_data.get("bname")
            price=form.cleaned_data.get("price")
            pages=form.cleaned_data.get("pages")
            author=form.cleaned_data.get("author")
            book=Book(bname=bname,pages=pages,price=price,author=author)
            book.save()
            return redirect("getbook")
    return render(request,"books/bookcreate.html",context)
    