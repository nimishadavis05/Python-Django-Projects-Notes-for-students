from django.contrib import admin

# Register your models here.
from billing.models import Products,Purchase
admin.site.register(Products)
admin.site.register(Purchase)