from django.shortcuts import render,redirect
from django.views.generic import TemplateView
from billing.forms import AddProduct,AddPurchase,OrderForm,OrderLinesForm
from .models import Products,Purchase,Order,OrderLines
from django.db.models import Sum,Count
from django.core.paginator import Paginator

# Create your views here.

class Index(TemplateView):
    template_name="billing/index.html"

class addproduct(TemplateView):
	form_class=AddProduct()
	template_name="billing/addproduct.html"
	context={}
	def get(self,request,*args,**kwargs):
		form=AddProduct()
		self.context["form"]=form
		return render(request,self.template_name,self.context)
	def post(self,request,*args,**kwargs):
		form=AddProduct(request.POST)
		if form.is_valid():
			form.save()
			return redirect("viewproduct")
		else:
			self.context["form"]=form
			return render(request,self.template_name,self.context)

class viewproduct(TemplateView):
	model=Products
	template_name="billing/listproduct.html"
	context={}
	def get_query_set(self):
		return self.model.objects.all()
	def get(self,request,*args,**kwargs):
		self.context["products"]=self.get_query_set()
		return render(request,self.template_name,self.context)

class editproduct(TemplateView):
	model=Products
	template_name="billing/editproduct.html"
	context={}
	def get_query_set(self,id):
		return self.model.objects.get(id=id)
	def get(self,request,*args,**kwargs):
		product=self.get_query_set(kwargs.get("pk"))
		form=AddProduct(instance=product)
		self.context["form"]=form
		return render(request,self.template_name,self.context)
	def post(self,request,*args,**kwargs):
		product=self.get_query_set(kwargs.get("pk"))
		form=AddProduct(instance=product,data=request.POST)
		if form.is_valid():
			form.save()
			return redirect("viewproduct")
		else:
			self.context["form"]=form
			return render(request,self.template_name,self.context)

class deleteproduct(TemplateView):
	model=Products
	template_name="billing/deleteproduct.html"
	context={}
	def get_query_set(self,id):
		return self.model.objects.get(id=id)
	def get(self,request,*args,**kwargs):
		product=self.get_query_set(kwargs.get("pk"))
		product.delete()
		return redirect("viewproduct")

class addpurchase(TemplateView):
	form_class=AddPurchase()
	template_name="billing/addpurchase.html"
	context={}
	def get(self,request,*args,**kwargs):
		form=AddPurchase()
		self.context["form"]=form
		return render(request,self.template_name,self.context)
	def post(self,request,*args,**kwargs):
		form=AddPurchase(request.POST)
		if form.is_valid():
			form.save()
			return redirect("viewpurchase")
		else:
			self.context["form"]=form
			return render(request,self.template_name,self.context)


class viewpurchase(TemplateView):
	model=Purchase
	template_name="billing/viewpurchase.html"
	context={}
	def get_query_set(self):
		return self.model.objects.all()
	def get(self,request,*args,**kwargs):
		self.context["purchases"]=self.get_query_set()
		return render(request,self.template_name,self.context)


class editpurchase(TemplateView):
	model=Purchase
	template_name="billing/editpurchase.html"
	context={}
	def get_query_set(self,id):
		return self.model.objects.get(id=id)
	def get(self,request,*args,**kwargs):
		product=self.get_query_set(kwargs.get("pk"))
		form=AddPurchase(instance=product)
		self.context["form"]=form
		return render(request,self.template_name,self.context)
	def post(self,request,*args,**kwargs):
		product=self.get_query_set(kwargs.get("pk"))
		form=AddPurchase(instance=product,data=request.POST)
		if form.is_valid():
			form.save()
			return redirect("viewpurchase")
		else:
			self.context["form"]=form
			return render(request,self.template_name,self.context)

class deletepurchase(TemplateView):
	model=Purchase
	template_name="billing/deleteurchase.html"
	context={}
	def get_query_set(self,id):
		return self.model.objects.get(id=id)
	def get(self,request,*args,**kwargs):
		product=self.get_query_set(kwargs.get("pk"))
		product.delete()
		return redirect("viewpurchase")


class OrderView(TemplateView):
	model=Order
	template_name="billing/order.html"
	context={}
	def get(self,request,*args,**kwargs):
		orders=Order.objects.all().last()
		bill_no=int(orders.bill_no)
		bill_no+=1
		bill_no=str(bill_no)
		
		form=OrderForm(initial={"bill_no":bill_no})
		self.context["form"]=form
		return render(request,self.template_name,self.context)
	def post(self,request,*args,**kwargs):
		form=OrderForm(request.POST)
		if form.is_valid():
			billno=form.cleaned_data.get("bill_no")
			form.save()
			return redirect("OrderLinesView",billno=billno)
		else:
			self.context["form"]=form
			return render(request,self.template_name,self.context)

class OrderLinesView(TemplateView):
	model=OrderLines
	template_name="billing/orderlines.html"
	context={}
	def get(self,request,*args,**kwargs):
		billno=kwargs.get("billno")
		self.context["billno"]=billno
		print(billno)
		bill=Order.objects.get(bill_no=billno)
		form=OrderLinesForm(initial={"bill_no":billno})
		self.context["form"]=form
		return render(request,self.template_name,self.context)

	def post(self,request,*args,**kwargs):
		form=OrderLinesForm(request.POST)
		if form.is_valid():
			billno=kwargs.get("billno")

			bill_no=form.cleaned_data.get("bill_no")
			product_name=form.cleaned_data.get("product_name")
			product_qy=form.cleaned_data.get("product_qty")

			# print(bill_no,product_name,product_qty)

			getproductname=Products.objects.get(product_name=product_name)

			price=Purchase.objects.get(product_name__product_name=product_name)

			qtys=price.quantity
			sellprices=price.selling_price
			amounts=product_qy*sellprices

			balanceqty=(qtys-product_qy)
			print(balanceqty)
			price.qty=balanceqty
			price.save()
			self.context["price"]=price
			bill=Order.objects.get(bill_no=billno)
			form=OrderLinesForm(initial={"bill_no":billno})
			self.context["form"]=form
			val=OrderLines(bill_no=bill,product_name=getproductname,product_qty=product_qy,amount=amounts)
			val.save()

			sumofamount=OrderLines.objects.filter(bill_no=bill).aggregate(Sum('amount'))
			self.context["total"]=sumofamount
			print(sumofamount)

			bill.bill_total=sumofamount
			print(bill.bill_total["amount__sum"])
			Order.objects.filter(bill_no=billno).update(bill_total=bill.bill_total["amount__sum"])

			getorderlinedatas=OrderLines.objects.filter(bill_no=bill)
			self.context["forms"]=getorderlinedatas
			return render(request,self.template_name,self.context)

		else:
			self.contextp["form"]=form
			return render(request,self.template_name,self.context)


class BillGenerate(TemplateView):
    model = OrderLines
    template_name = "billing/bill_generate.html"
    context = {}
    def get_object(self,id):
        return self.model.objects.get(bill_no=id)

    def get(self, request, *args, **kwargs):
        billnum = kwargs.get("bill_no")
        print(billnum)
        bill = Order.objects.get(bill_no=billnum)
        self.context["getorder"] = bill
        getorderlinesdatas = OrderLines.objects.filter(bill_no__bill_no=billnum)
        self.context["getallitems"] = getorderlinesdatas
        return render(request, self.template_name, self.context)
