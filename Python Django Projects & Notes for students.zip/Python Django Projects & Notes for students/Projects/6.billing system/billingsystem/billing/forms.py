from django.forms import ModelForm
# User
from billing.models import Products,Purchase,Order,OrderLines
from django import forms
class AddProduct(ModelForm):
    class Meta:
        model=Products
        fields="__all__"

class AddPurchase(ModelForm):
    class Meta:
        model=Purchase
        fields=["product_name","quantity","purchase_price","selling_price"]
        widgets={"quantity":forms.TextInput(attrs={'class':'form-control'})}


class OrderForm(ModelForm):
    bill_no = forms.CharField(widget=forms.TextInput(attrs={'readonly': 'readonly'}))
    class Meta:
        model=Order
        fields=["bill_no","customer_name","phone_number"]

class OrderLinesForm(forms.Form):

    bill_no = forms.CharField(widget=forms.TextInput(attrs={'readonly': 'readonly'}))
    queryset = Purchase.objects.all().filter(quantity__gte=1).values_list('product_name__product_name', flat=True)
    choices = [(name, name) for name in queryset]
    product_name=forms.ChoiceField(choices=choices,required=False,widget=forms.Select())
    product_qty=forms.IntegerField()
    class Meta:
        model=OrderLines
        fields=["bill_no","product_name","product_qty"]
