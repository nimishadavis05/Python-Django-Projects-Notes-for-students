
from django.contrib import admin
from django.urls import path,include
from .views import Books,BookDetails
from rest_framework.urlpatterns import format_suffix_patterns
# BookView,
urlpatterns = [

    path("books",Books.as_view()),
    path("books/<int:pk>",BookDetails.as_view())    

    
]
