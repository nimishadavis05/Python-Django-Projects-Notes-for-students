from rest_framework.serializers import ModelSerializer
from Books.models import Book
from rest_framework import exceptions
class BookSerializer(ModelSerializer):
	class Meta:
		model=Book
		fields=["book_name","pages","price","author"]
	def validate(self,data):
		print(data)
		price=data.get("price")
		if price<50:
			msg="have to provide greater than 50"
			raise exceptions.ValidationError(msg)
		return data