from django import forms
class AccountCreateForm(forms.Form):
    pname=forms.CharField(max_length=120)
    accno=forms.CharField(max_length=120)
    actype=forms.CharField(max_length=100)
    balance=forms.IntegerField()
    phonenumber=forms.CharField(max_length=12)
    mpin=forms.CharField(max_length=6)


class LoginForm(forms.Form):
    phonenumber=forms.CharField(max_length=12)
    mpin=forms.CharField(max_length=6)
