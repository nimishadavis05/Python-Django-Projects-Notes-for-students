from django.db import models

# Create your models here.
class BankAccount(models.Model):
    pname=models.CharField(max_length=120)
    accno=models.CharField(max_length=150,unique=True)
    actype=models.CharField(max_length=100)
    balance=models.IntegerField(max_length=150)
    phonenumber=models.CharField(max_length=12,unique=True)
    mpin=models.CharField(max_length=6,unique=True)
    def __str__(self):
        return self.pname