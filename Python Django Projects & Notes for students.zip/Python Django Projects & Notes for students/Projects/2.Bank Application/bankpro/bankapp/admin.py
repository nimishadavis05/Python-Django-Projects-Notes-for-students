from django.contrib import admin

# Register your models here.
from bankapp.models import BankAccount

admin.site.register(BankAccount)
