from django.shortcuts import render
from bankapp.models import BankAccount
# Create your views here.
from bankapp.forms import AccountCreateForm,LoginForm


def Home(request):
    return render(request,"bankapp/home.html")
def CreateAccount(request):
    template_name="bankapp/index.html"
    form=AccountCreateForm()
    context={}
    context["form"]=form
    if(request.method=="POST"):
        form=AccountCreateForm(request.POST)
        if(form.is_valid()):
            pname=form.cleaned_data.get("pname")
            accno=form.cleaned_data.get("accno")
            actype=form.cleaned_data.get("actype")
            balance=form.cleaned_data.get("balance")
            phonenumber=form.cleaned_data.get("phonenumber")
            mpin=form.cleaned_data.get("mpin")
            obj=BankAccount(pname=pname,accno=accno,actype=actype,balance=balance,phonenumber=phonenumber,mpin=mpin)
            obj.save()
            return render(request,template_name,context)
    return render(request,template_name,context)

def LoginView(request):
    form=LoginForm()
    context={}
    context["form"]=form
    if(request.method=="POST"):
        form=LoginForm(request.POST)
        if(form.is_valid()):
            phone=form.cleaned_data.get("phonenumber")
            mpin=form.cleaned_data.get("mpin")
            pname=form.cleaned_data.get("pname")

            try:
                obj=BankAccount.objects.get(phonenumber=phone)
                if((obj.phonenumber==phone) & (obj.mpin==mpin)):
                    print("user exist")
                    return render(request,"bankapp/userhome.html")
            except Exception as e:
                
                print("invalid credentials")
                context["form"] = form
                return render(request,"bankapp/login.html", context)
    return render(request,"bankapp/login.html",context)
