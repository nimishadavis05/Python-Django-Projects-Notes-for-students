# # name="nimisha"
#
#
# name=input("Enter your name here:") # read msg from console/keyboaard
# print("my name is",name) #display
#
#
# #afshin is 20 years old


# a=10
# b=20

a=input("enter first number")
b=input("enter second no")
c=a+b
print(c)