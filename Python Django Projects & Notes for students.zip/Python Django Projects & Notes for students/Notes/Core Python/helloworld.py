# print("hello world") #print() is used to display msg
# print('hi')

name="demo"
age=22

# demo is 22 years old

print(name,"is",age,"years old")
