class Person:
    def setValues(self,name,age):
        self.age=age
        self.name=name
    def printvalues(self):
        print("name:",self.name)
        print("age:",self.age)
obj=Person()
obj.setValues("nimisha",22)
obj.printvalues()