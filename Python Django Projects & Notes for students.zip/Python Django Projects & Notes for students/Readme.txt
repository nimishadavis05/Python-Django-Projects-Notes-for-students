Hey Friend
I'm Nimisha.
If you need training in python-Django,Datascience,ML,AI,DL just ping me


Linkedin : https://www.linkedin.com/in/theofficialnimisha/
Instagram : http://instagram.com/theofficialnimisha


Note : Training will be paid

